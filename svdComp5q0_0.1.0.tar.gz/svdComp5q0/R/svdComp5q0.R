#' svdComp5q0: Child or Child/Adult Mortality-Indexed Model Life Tables.
#'
#' Implementation of the SVD-Comp mortality model. The \code{predictLT} function predicts full age schedules of mortality in
#'     single year or five-year age groups from either child mortality (5q0) alone or both child (5q0) and adult mortality (45q15).
#'     For a full description of the model see arXiv preprint \doi{doi:10.48550/arXiv.1612.01408} and published paper in the journal \emph{Demography}
#'     \doi{doi:10.1007/s13524-019-00785-3}.
#'
#' @section svdComp5q0 functions:
#' \strong{predictLT} takes child or child/adult mortality and generates full age schedules of mortality.
#'
#' @docType package
#' @name svdComp5q0
NULL
